import java.util.*;

public class SulphatesComparator implements Comparator<WineSample> {
    public int compare(WineSample a, WineSample b) {
        return a.getSulphates() < b.getSulphates() ? -1 :
                a.getSulphates() > b.getSulphates() ? 1 : 0;
    }
}
import java.util.*;

public class VolatileAcidityComparator implements Comparator<WineSample> {
    public int compare(WineSample a, WineSample b) {
        return a.getVolatileAcidity() < b.getVolatileAcidity() ? -1 :
                a.getVolatileAcidity() > b.getVolatileAcidity() ? 1 : 0;
    }
}
public class NoOperatorValueException extends Exception {
    public NoOperatorValueException() {
    }

    public NoOperatorValueException(String message) {
        super(message);
    }

    public NoOperatorValueException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoOperatorValueException(Throwable cause) {
        super(cause);
    }

    public NoOperatorValueException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}

import java.io.*;
import java.util.*;
import java.lang.reflect.*;

public class PWB {
	public static final int RED = 0;
	public static final int WHITE = 1;
	public static final int ALL_SAMPLES = 2;
	
	private List<WineSample> wineSamples = new ArrayList<WineSample>();
	private List<WineSample> redSamples = new ArrayList<WineSample>();
	private List<WineSample> whiteSamples = new ArrayList<WineSample>();
	private List<Query<WineSample>> queries = new ArrayList<Query<WineSample>>();
	
	public List<WineSample> getWineSamples() {
		return wineSamples;
	}
	
	public List<WineSample> getRedSamples() {
		return redSamples;
	}
	
	public List<WineSample> getWhiteSamples() {
		return whiteSamples;
	}
	
	public List<Query<WineSample>> getQueries() {
		return queries;
	}
	
	public void readFiles(String s1, String s2) throws FileNotFoundException, IOException {
		BufferedReader redWineInputFile = new BufferedReader(new FileReader(s1));
		BufferedReader whiteWineInputFile = new BufferedReader(new FileReader(s2));
			
		String currentLine;
		int sampleIDGenerator = 1;
		int inputRow = 2; //for tracking the location of data entry errors in the input files
		redWineInputFile.readLine(); //skipping over heading rows
		whiteWineInputFile.readLine();
			
		while ((currentLine = redWineInputFile.readLine()) != null) {
			String[] splitData = currentLine.split(";");
			
			//user will be notified of any input file rows which do not contain 12 properly 
			//formatted data points, and the current iteration of the loop will end before a
			//new WineSample object is created
			if (splitData.length != 12) {
				System.out.println("Data entry error at row " + inputRow + " of red wine input file");
				inputRow++;
				continue;
			}
			else {
				try {
					WineSample currentSample = new WineSample();
					currentSample.setSampleID(sampleIDGenerator);
					currentSample.setWineType(WineSample.RED);
					currentSample.setFixedAcidity(Double.parseDouble(splitData[0]));
					currentSample.setVolatileAcidity(Double.parseDouble(splitData[1]));
					currentSample.setCitricAcid(Double.parseDouble(splitData[2]));
					currentSample.setResidualSugar(Double.parseDouble(splitData[3]));
					currentSample.setChlorides(Double.parseDouble(splitData[4]));
					currentSample.setFreeSulfurDioxide(Double.parseDouble(splitData[5]));
					currentSample.setTotalSulfurDioxide(Double.parseDouble(splitData[6]));
					currentSample.setDensity(Double.parseDouble(splitData[7]));
					currentSample.setpH(Double.parseDouble(splitData[8]));
					currentSample.setSulphates(Double.parseDouble(splitData[9]));
					currentSample.setAlcohol(Double.parseDouble(splitData[10]));
					currentSample.setQuality(Integer.parseInt(splitData[11]));
					wineSamples.add(currentSample);
					redSamples.add(currentSample);
					sampleIDGenerator++;
					inputRow++;
				}
				//detecting and handling additional data entry errors in input files, e.g.
				//the inclusion of non-numeric characters
				catch (NumberFormatException nfe) {
					System.out.println("Data entry error at row " + inputRow + " of red wine input file");
					inputRow++;
					continue;
				}
			}
		}
		
		inputRow = 2; //reinitialising to sync up with second input file
			
		while ((currentLine = whiteWineInputFile.readLine()) != null) {
			String[] splitData = currentLine.split(";");
			
			if (splitData.length != 12) {
				System.out.println("Data entry error at row " + inputRow + " of white wine input file");
				inputRow++;
				continue;
			}
			else {
				try {
					WineSample currentSample = new WineSample();
					currentSample.setSampleID(sampleIDGenerator);
					currentSample.setWineType(WineSample.WHITE);
					currentSample.setFixedAcidity(Double.parseDouble(splitData[0]));
					currentSample.setVolatileAcidity(Double.parseDouble(splitData[1]));
					currentSample.setCitricAcid(Double.parseDouble(splitData[2]));
					currentSample.setResidualSugar(Double.parseDouble(splitData[3]));
					currentSample.setChlorides(Double.parseDouble(splitData[4]));
					currentSample.setFreeSulfurDioxide(Double.parseDouble(splitData[5]));
					currentSample.setTotalSulfurDioxide(Double.parseDouble(splitData[6]));
					currentSample.setDensity(Double.parseDouble(splitData[7]));
					currentSample.setpH(Double.parseDouble(splitData[8]));
					currentSample.setSulphates(Double.parseDouble(splitData[9]));
					currentSample.setAlcohol(Double.parseDouble(splitData[10]));
					currentSample.setQuality(Integer.parseInt(splitData[11]));
					wineSamples.add(currentSample);
					whiteSamples.add(currentSample);
					sampleIDGenerator++;
					inputRow++;
				}
				catch (NumberFormatException nfe) {
					System.out.println("Data entry error at row " + inputRow + " of white wine input file");
					inputRow++;
					continue;
				}
			}
		}
	}	
}
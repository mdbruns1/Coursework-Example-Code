import java.util.*;

public class FixedAcidityComparator implements Comparator<WineSample> {
    public int compare(WineSample a, WineSample b) {
        return a.getFixedAcidity() < b.getFixedAcidity() ? -1 :
                a.getFixedAcidity() > b.getFixedAcidity() ? 1 : 0;
    }
}
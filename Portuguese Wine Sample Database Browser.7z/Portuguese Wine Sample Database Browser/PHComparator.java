import java.util.*;

public class PHComparator implements Comparator<WineSample> {
	public int compare(WineSample a, WineSample b) {
		return a.getpH() < b.getpH() ? -1 : a.getpH() > b.getpH() ? 1 : 0;
	}
}
import java.util.*;

public class AlcoholComparator implements Comparator<WineSample> {
	public int compare(WineSample a, WineSample b) {
			return a.getAlcohol() < b.getAlcohol() ? -1 : 
				a.getAlcohol() > b.getAlcohol() ? 1 : 0; 
	}
}
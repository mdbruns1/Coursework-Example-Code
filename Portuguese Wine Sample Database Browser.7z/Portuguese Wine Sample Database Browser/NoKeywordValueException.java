public class NoKeywordValueException extends Exception {
    public NoKeywordValueException() {
    }

    public NoKeywordValueException(String message) {
        super(message);
    }

    public NoKeywordValueException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoKeywordValueException(Throwable cause) {
        super(cause);
    }

    public NoKeywordValueException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class QueryPanel extends JPanel {
    //creating instance variables for components that need to be accessed in the SubmitQueryListener class
    private JPanel wineTypePanel = new JPanel();
    private JPanel resultsFilterPanel = new JPanel();
    private JPanel conditionsPanel = new JPanel();
    private JRadioButton red = new JRadioButton("Red");
    private JRadioButton white = new JRadioButton("White");
    private JRadioButton both = new JRadioButton("Both Red and White");
    private JRadioButton allResults = new JRadioButton("Display all results");
    private JRadioButton firstTenOnly = new JRadioButton("Display only the first 10 results");
    private JButton submitQuery = new JButton("Sumbit your query");

    public QueryPanel() {
       setLayout(new BorderLayout());
       JPanel topPanel = new JPanel();
       conditionsPanel.setLayout(new WrapLayout());
       add(topPanel, BorderLayout.NORTH);
       add(conditionsPanel, BorderLayout.CENTER);

       //user has three options for selecting wine type(s)
       ButtonGroup wineTypeButtons = new ButtonGroup();
       wineTypeButtons.add(red);
       wineTypeButtons.add(white);
       wineTypeButtons.add(both);
       wineTypePanel.add(red);
       wineTypePanel.add(white);
       wineTypePanel.add(both);
       wineTypePanel.setBorder(BorderFactory.createTitledBorder(
               BorderFactory.createEtchedBorder(), "Wine Type Selection"));
       topPanel.add(wineTypePanel);

       //user has two options for how many results are displayed
       ButtonGroup resultsFilter = new ButtonGroup();
       resultsFilter.add(allResults);
       resultsFilter.add(firstTenOnly);
       resultsFilterPanel.add(allResults);
       resultsFilterPanel.add(firstTenOnly);
       resultsFilterPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Results Filter"));
       topPanel.add(resultsFilterPanel);

       //buttons for adding and removing condition input fields and for submitting a finished query
       JButton addCondition = new JButton("Add a new condition");
       topPanel.add(addCondition);
       JButton removeCondition = new JButton("Remove last condition");
       topPanel.add(removeCondition);
       JButton clearConditions = new JButton("Remove all conditions");
       topPanel.add(clearConditions);
       topPanel.add(submitQuery);

       //clicking the "Add a new condition" button creates a new panel containing components for user inputs
       addCondition.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e) {
               ConditionPanel newCondition = new ConditionPanel();
               conditionsPanel.add(newCondition);
               conditionsPanel.revalidate();
               conditionsPanel.repaint();
           }
       });

       //deletes the last panel of condition input fields
       removeCondition.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e) {
               if (conditionsPanel.getComponentCount() != 0) {
                   conditionsPanel.remove((conditionsPanel.getComponentCount()) - 1);
                   conditionsPanel.revalidate();
                   conditionsPanel.repaint();
               }
           }
       });

       //deletes all panels of condition input fields
        clearConditions.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (conditionsPanel.getComponentCount() != 0) {
                    conditionsPanel.removeAll();
                    conditionsPanel.revalidate();
                    conditionsPanel.repaint();
                }
            }
        });
    }

    public JPanel getWineTypePanel() {
        return wineTypePanel;
    }

    public void setWineTypePanel(JPanel wineTypePanel) {
        this.wineTypePanel = wineTypePanel;
    }

    public JPanel getResultsFilterPanel() {
        return resultsFilterPanel;
    }

    public void setResultsFilterPanel(JPanel resultsFilterPanel) {
        this.resultsFilterPanel = resultsFilterPanel;
    }

    public JPanel getConditionsPanel() {
        return conditionsPanel;
    }

    public void setConditionsPanel(JPanel conditionsPanel) {
        this.conditionsPanel = conditionsPanel;
    }

    public JRadioButton getRed() {
        return red;
    }

    public void setRed(JRadioButton red) {
        this.red = red;
    }

    public JRadioButton getWhite() {
        return white;
    }

    public void setWhite(JRadioButton white) {
        this.white = white;
    }

    public JRadioButton getBoth() {
        return both;
    }

    public void setBoth(JRadioButton both) {
        this.both = both;
    }

    public JRadioButton getAllResults() {
        return allResults;
    }

    public void setAllResults(JRadioButton allResults) {
        this.allResults = allResults;
    }

    public JRadioButton getFirstTenOnly() {
        return firstTenOnly;
    }

    public void setFirstTenOnly(JRadioButton firstTenOnly) {
        this.firstTenOnly = firstTenOnly;
    }

    public JButton getSubmitQuery() {
        return submitQuery;
    }

    public void setSubmitQuery(JButton submitQuery) {
        this.submitQuery = submitQuery;
    }
}
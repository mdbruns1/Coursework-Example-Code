import javax.swing.*;
import java.awt.*;

public class ResultsPanel extends JPanel {
    //text area needs to be accessible to SubmitQueryListener class and so is an instance variable
    private JTextArea resultsText = new JTextArea("View the results of your query here...", 45, 90);

    public ResultsPanel() {
        resultsText.setEditable(false);
        JScrollPane scrollableResults = new JScrollPane(resultsText);
        add(scrollableResults);
    }

    public JTextArea getResultsText() {
        return resultsText;
    }

    public void setResultsText(JTextArea resultsText) {
        this.resultsText = resultsText;
    }
}
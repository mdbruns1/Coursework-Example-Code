import java.util.*;

public class QualityComparator implements Comparator<WineSample> {
	public int compare(WineSample a, WineSample b) {
		return a.getQuality() < b.getQuality() ? -1 : 
		a.getQuality() > b.getQuality() ? 1 : 0;
	}
}
import java.util.*;
import java.lang.reflect.*;

public class Query<T extends Comparable> {
	public static final int ALL_RESULTS = 0;
	public static final int FIRST_TEN_ONLY = 1;

	private int dataset;
	//for mapping dataset values to the different collections of data objects
	private Map<Integer, Collection<T>> datasetTable;
	private List<Condition> conditions = new ArrayList<Condition>(); 
	private List<T> queryResults = new ArrayList<T>();
	private int resultsFilter;
	
	public int getDataset() {
		return dataset;
	}
	
	public Map<Integer, Collection<T>> getDatasetTable() {
		return datasetTable;
	}
	
	public List<Condition> getConditions() {
		return conditions;
	}
	
	public List<T> getQueryResults() {
		return queryResults;
	}

	public int getResultsFilter() { 
		return resultsFilter; 
	}
	
	public void setDataset(int i) {
		dataset = i;
	}
	
	public void setDatasetTable(Map<Integer, Collection<T>> m) {
		datasetTable = m;
	}
	
	public void addCondition(Condition c) {
		conditions.add(c);
	}

	public void setResultsFilter(int i) { resultsFilter = i; }
	
	public void executeQuery() {
		try {
			//iterating through the target objects for the query by looking up the
			//correct collection in the HashMap
			for (T nextDataObject : datasetTable.get(dataset)) {
				queryResults.add(nextDataObject); //target object added to result set by default 
				for (Condition nextCondition : conditions) {
					//target object removed if any of the query's conditions are untrue for it
					if (nextCondition.isTrue(nextDataObject) == false) {
						queryResults.remove(nextDataObject);
					}
				}
			}
		}
		catch (IllegalAccessException iae) {
			iae.printStackTrace();
		}
		catch (InvocationTargetException ite) {
			ite.printStackTrace();
		}
		catch (IllegalOperatorValueException iove) {
			iove.printStackTrace();
		}
		catch (IllegalDataObjectValueException idove) {
			idove.printStackTrace();
		}
	}
}
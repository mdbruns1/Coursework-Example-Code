import javax.swing.*;
import java.awt.*;

public class StatsPanel extends JPanel {
    //components that are accessed by the SubmitQueryListener class are rendered as instance variables
    private JTable statsTable;
    private JTextArea queryResultSetSize = new JTextArea(1, 6);

    public StatsPanel() {
        setLayout(new BorderLayout());
        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("The total number of wine samples which match your query:"));
        topPanel.add(queryResultSetSize);
        add(topPanel, BorderLayout.NORTH);

        //creating a default table model with blank values except for the column and row headings
        String[] columnNames = {"Attribute", "Minimum Value", "Maximum Value", "Average Value"};
        Object[][] blankRowData = {{"Fixed Acidity", "", "",""}, {"Volatile Acidity", "", "",""}, {"Citric Acid", "", "",""},
                {"Residual Sugar", "", "",""}, {"Chlorides", "", "",""}, {"Free Sulfur Dioxide", "", "",""},
                {"Total Sulfur Dioxide", "", "",""}, {"Density", "", "",""}, {"pH", "", "",""},
                {"Sulphates", "", "",""}, {"Alcohol", "", "",""}, {"Quality", "", "",""}};
        statsTable = new JTable(blankRowData, columnNames);
        statsTable.setEnabled(false);
        statsTable.setRowHeight(33);
        JScrollPane scrollableStatsTable = new JScrollPane(statsTable);
        add(scrollableStatsTable, BorderLayout.CENTER);
    }

    public JTable getStatsTable() {
        return statsTable;
    }

    public void setStatsTable(JTable statsTable) {
        this.statsTable = statsTable;
    }

    public JTextArea getQueryResultSetSize() {
        return queryResultSetSize;
    }

    public void setQueryResultSetSize(JTextArea queryResultSetSize) {
        this.queryResultSetSize = queryResultSetSize;
    }
}

public class IllegalOperatorValueException extends Exception {
    public IllegalOperatorValueException() {
    }

    public IllegalOperatorValueException(String message) {
        super(message);
    }

    public IllegalOperatorValueException(String message, Throwable cause) {
        super(message, cause);
    }

    public IllegalOperatorValueException(Throwable cause) {
        super(cause);
    }

    public IllegalOperatorValueException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}

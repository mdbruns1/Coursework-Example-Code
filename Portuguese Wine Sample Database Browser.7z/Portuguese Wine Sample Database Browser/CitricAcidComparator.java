import java.util.*;

public class CitricAcidComparator implements Comparator <WineSample> {
	public int compare(WineSample a, WineSample b) {
			return a.getCitricAcid() < b.getCitricAcid() ? -1 :
			a.getCitricAcid() > b.getCitricAcid() ? 1 : 0;
	}
}
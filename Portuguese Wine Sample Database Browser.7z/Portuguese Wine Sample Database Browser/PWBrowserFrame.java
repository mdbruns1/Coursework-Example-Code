import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class PWBrowserFrame extends JFrame {
    //instance variables are accessible to private inner SubmitQueryListener class as well as main method
    private QueryPanel qp = new QueryPanel();
    private ResultsPanel rp = new ResultsPanel();
    private StatsPanel sp = new StatsPanel();
    private Map<Integer, Collection<WineSample>> datasets;
    private Map<String, Method> keywords;

    public PWBrowserFrame() {
        setTitle("Portuguese Wine Browser");
        Toolkit tk = Toolkit.getDefaultToolkit();
        Dimension dim = tk.getScreenSize();
        setSize(dim); //browser size defaults to screen size
        setLayout(new BorderLayout());

        JPanel jp = new JPanel();
        jp.add(rp);
        jp.add(Box.createHorizontalStrut(25));
        jp.add(sp);
        Container contentPane = getContentPane();
        contentPane.add(qp, BorderLayout.NORTH);
        contentPane.add(jp, BorderLayout.CENTER);
        JScrollPane scrollablePane = new JScrollPane(contentPane);
        setContentPane(scrollablePane);

        SubmitQueryListener sql = new SubmitQueryListener();
        qp.getSubmitQuery().addActionListener(sql); //submitQuery button on QueryPanel registered as action source
    }

    public Map<Integer, Collection<WineSample>> getDatasets() {
        return datasets;
    }

    public void setDatasets(Map<Integer, Collection<WineSample>> datasets) {
        this.datasets = datasets;
    }

    public Map<String, Method> getKeywords() {
        return keywords;
    }

    public void setKeywords(Map<String, Method> keywords) {
        this.keywords = keywords;
    }

    //listener class for responding to submitQuery button presses
    private class SubmitQueryListener implements ActionListener {
        public void actionPerformed(ActionEvent ae) {
            Query<WineSample> userQuery = new Query<WineSample>();
            userQuery.setDatasetTable(datasets);
            try {
                //setting the subset of wine samples associated with the query based on the user's button selection
                if (qp.getRed().isSelected()) {
                    userQuery.setDataset(PWB.RED);
                }
                else if (qp.getWhite().isSelected()) {
                    userQuery.setDataset(PWB.WHITE);
                }
                else if (qp.getBoth().isSelected()) {
                    userQuery.setDataset(PWB.ALL_SAMPLES);
                }
                else {
                    throw new NoWineTypeSelectionException();
                }

                //tracking whether the user wants all results of their query or only the first ten displayed on screen
                if (qp.getAllResults().isSelected()) {
                    userQuery.setResultsFilter(Query.ALL_RESULTS);
                }
                else if (qp.getFirstTenOnly().isSelected()) {
                    userQuery.setResultsFilter(Query.FIRST_TEN_ONLY);
                }
                else {
                    throw new NoResultsFilterSelectionException();
                }

                //obtaining all the condition panels, each containing user inputs relevant to a query condition, and
                //iterating through them to create necessary object representations
                Component[] userConditions = qp.getConditionsPanel().getComponents();
                for (Component nextUserCondition : userConditions) {
                    ConditionPanel cp = (ConditionPanel) nextUserCondition;
                    Condition userCondition = new Condition();

                    //seeing which keyword the user has chosen
                    String keywordInput = (String) cp.getKeywordOptions().getSelectedItem();
                    if (keywordInput.equals("")) {
                        throw new NoKeywordValueException();
                    }
                    else {
                        userCondition.setKeyword(keywordInput);
                    }

                    //seeing which operator sign the user has chosen
                    String operatorInput = (String) cp.getOperatorOptions().getSelectedItem();
                    if (operatorInput.equals("<")) {
                        userCondition.setOperator(Condition.LESSER);
                    }
                    else if (operatorInput.equals("<=")) {
                        userCondition.setOperator(Condition.LESSER_EQUAL);
                    }
                    else if (operatorInput.equals("=")) {
                        userCondition.setOperator(Condition.EQUAL);
                    }
                    else if (operatorInput.equals("!=")) {
                        userCondition.setOperator(Condition.NOT_EQUAL);
                    }
                    else if (operatorInput.equals(">=")) {
                        userCondition.setOperator(Condition.GREATER_EQUAL);
                    }
                    else if (operatorInput.equals(">")) {
                        userCondition.setOperator(Condition.GREATER);
                    }
                    else {
                        throw new NoOperatorValueException();
                    }

                    //reading the text input supplied by the user to obtain a condition value
                    double valueInput = Double.parseDouble(cp.getValueField().getText());
                    userCondition.setValue(valueInput);
                    userCondition.setKeywordMethods(keywords);

                    //assuming all the inputs were valid, a fully instantiated Condition object is added to the Query object
                    //which is then executed, filling the Query object's resultsSet field
                    userQuery.addCondition(userCondition);
                }
            }
            //return statements prevent malformed queries from executing with error dialogs informing the user of any missing or 
	    //invalid inputs
            catch (NoWineTypeSelectionException nwtse) {
                JOptionPane.showMessageDialog(qp.getWineTypePanel(), "Please make a wine type selection.");
                return;
            }
            catch (NoResultsFilterSelectionException nrfse) {
                JOptionPane.showMessageDialog(qp.getResultsFilterPanel(), "Please select a results filter option.");
                return;
            }
            catch (NoKeywordValueException nkve) {
                JOptionPane.showMessageDialog(qp.getConditionsPanel(), "Please select a keyword.");
                return;
            }
            catch (NoOperatorValueException nove) {
                JOptionPane.showMessageDialog(qp.getConditionsPanel(), "Please select an operator.");
                return;
            }
            catch (NumberFormatException nfe) {
                JOptionPane.showMessageDialog(qp.getConditionsPanel(), "Value fields only accept numbers.");
                return;
            }

            userQuery.executeQuery();
            rp.getResultsText().setText("");

            //displaying the results of the user's query in the ResultsPanel text area
            if (userQuery.getQueryResults().isEmpty()) {
                rp.getResultsText().append("Your query prodcued no matching wine samples...");
            }
            //avoiding ArrayOutOfBoundsExceptions by treating result sets with 10 or less elements the same as
            //result sets where the user has selected the "Display all results" button even if "Dispaly only
            //the first 10 results" is selected
            else if (userQuery.getResultsFilter() == Query.ALL_RESULTS || userQuery.getQueryResults().size() <= 10) {
                for (WineSample nextResult : userQuery.getQueryResults()) {
                    rp.getResultsText().append(nextResult.toString());
                    rp.getResultsText().append("\n");
                }
            }
            else {
                for (int i = 0; i < 10; i++) {
                    rp.getResultsText().append(userQuery.getQueryResults().get(i).toString());
                    rp.getResultsText().append("\n");
                }
            }
            rp.revalidate();
            rp.repaint();

            //displaying how many wine samples match the query overall
            sp.getQueryResultSetSize().setText(Integer.toString(userQuery.getQueryResults().size()));

            //setting cell values of the statsTable to blank if the user query produced no results
            if (userQuery.getQueryResults().isEmpty()) {
                sp.getStatsTable().setValueAt("", 0, 1);
                sp.getStatsTable().setValueAt("", 0, 2);
                sp.getStatsTable().setValueAt("", 0, 3);
                sp.getStatsTable().setValueAt("", 1, 1);
                sp.getStatsTable().setValueAt("", 1, 2);
                sp.getStatsTable().setValueAt("", 1, 3);
                sp.getStatsTable().setValueAt("", 2, 1);
                sp.getStatsTable().setValueAt("", 2, 2);
                sp.getStatsTable().setValueAt("", 2, 3);
                sp.getStatsTable().setValueAt("", 3, 1);
                sp.getStatsTable().setValueAt("", 3, 2);
                sp.getStatsTable().setValueAt("", 3, 3);
                sp.getStatsTable().setValueAt("", 4, 1);
                sp.getStatsTable().setValueAt("", 4, 2);
                sp.getStatsTable().setValueAt("", 4, 3);
                sp.getStatsTable().setValueAt("", 5, 1);
                sp.getStatsTable().setValueAt("", 5, 2);
                sp.getStatsTable().setValueAt("", 5, 3);
                sp.getStatsTable().setValueAt("", 6, 1);
                sp.getStatsTable().setValueAt("", 6, 2);
                sp.getStatsTable().setValueAt("", 6, 3);
                sp.getStatsTable().setValueAt("", 7, 1);
                sp.getStatsTable().setValueAt("", 7, 2);
                sp.getStatsTable().setValueAt("", 7, 3);
                sp.getStatsTable().setValueAt("", 8, 1);
                sp.getStatsTable().setValueAt("", 8, 2);
                sp.getStatsTable().setValueAt("", 8, 3);
                sp.getStatsTable().setValueAt("", 9, 1);
                sp.getStatsTable().setValueAt("", 9, 2);
                sp.getStatsTable().setValueAt("", 9, 3);
                sp.getStatsTable().setValueAt("", 10, 1);
                sp.getStatsTable().setValueAt("", 10, 2);
                sp.getStatsTable().setValueAt("", 10, 3);
                sp.getStatsTable().setValueAt("", 11, 1);
                sp.getStatsTable().setValueAt("", 11, 2);
                sp.getStatsTable().setValueAt("", 11, 3);
                sp.getStatsTable().revalidate();
                sp.getStatsTable().repaint();
            }
            else {
                //calculating min and max values for each wine sample attribute for the result set
                Double minFAcid = (Collections.min(userQuery.getQueryResults(), new FixedAcidityComparator())).getFixedAcidity();
                Double maxFAcid = (Collections.max(userQuery.getQueryResults(), new FixedAcidityComparator())).getFixedAcidity();
                Double minVAcid = (Collections.min(userQuery.getQueryResults(), new VolatileAcidityComparator())).getVolatileAcidity();
                Double maxVAcid = (Collections.max(userQuery.getQueryResults(), new VolatileAcidityComparator())).getVolatileAcidity();
                Double minCAcid = (Collections.min(userQuery.getQueryResults(), new CitricAcidComparator())).getCitricAcid();
                Double maxCAcid = (Collections.max(userQuery.getQueryResults(), new CitricAcidComparator())).getCitricAcid();
                Double minRSugar = (Collections.min(userQuery.getQueryResults(), new ResidualSugarComparator())).getResidualSugar();
                Double maxRSugar = (Collections.max(userQuery.getQueryResults(), new ResidualSugarComparator())).getResidualSugar();
                Double minChlor = (Collections.min(userQuery.getQueryResults(), new ChloridesComparator())).getChlorides();
                Double maxChlor = (Collections.max(userQuery.getQueryResults(), new ChloridesComparator())).getChlorides();
                Double minFSD = (Collections.min(userQuery.getQueryResults(), new FreeSulfurDioxideComparator())).getFreeSulfurDioxide();
                Double maxFSD = (Collections.max(userQuery.getQueryResults(), new FreeSulfurDioxideComparator())).getFreeSulfurDioxide();
                Double minTSD = (Collections.min(userQuery.getQueryResults(), new TotalSulfurDioxideComparator())).getTotalSulfurDioxide();
                Double maxTSD = (Collections.max(userQuery.getQueryResults(), new TotalSulfurDioxideComparator())).getTotalSulfurDioxide();
                Double minDens = (Collections.min(userQuery.getQueryResults(), new DensityComparator())).getDensity();
                Double maxDens = (Collections.max(userQuery.getQueryResults(), new DensityComparator())).getDensity();
                Double minpH = (Collections.min(userQuery.getQueryResults(), new PHComparator())).getpH();
                Double maxpH = (Collections.max(userQuery.getQueryResults(), new PHComparator())).getpH();
                Double minSulph = (Collections.min(userQuery.getQueryResults(), new SulphatesComparator())).getSulphates();
                Double maxSulph = (Collections.max(userQuery.getQueryResults(), new SulphatesComparator())).getSulphates();
                Double minAlc = (Collections.min(userQuery.getQueryResults(), new AlcoholComparator())).getAlcohol();
                Double maxAlc = (Collections.max(userQuery.getQueryResults(), new AlcoholComparator())).getAlcohol();
                Integer minQual = (Collections.min(userQuery.getQueryResults(), new QualityComparator())).getQuality();
                Integer maxQual = (Collections.max(userQuery.getQueryResults(), new QualityComparator())).getQuality();

                //calculating average values for each wine sample attribute for the result set
                double sum = 0;
                for (WineSample nextSample : userQuery.getQueryResults()) {
                    double nextValue = nextSample.getFixedAcidity();
                    sum += nextValue;
                }
                Double avgFAcid = (sum / userQuery.getQueryResults().size());
                sum = 0;

                for (WineSample nextSample : userQuery.getQueryResults()) {
                    double nextValue = nextSample.getVolatileAcidity();
                    sum += nextValue;
                }
                Double avgVAcid = (sum / userQuery.getQueryResults().size());
                sum = 0;

                for (WineSample nextSample : userQuery.getQueryResults()) {
                    double nextValue = nextSample.getCitricAcid();
                    sum += nextValue;
                }
                Double avgCAcid = (sum / userQuery.getQueryResults().size());
                sum = 0;

                for (WineSample nextSample : userQuery.getQueryResults()) {
                    double nextValue = nextSample.getResidualSugar();
                    sum += nextValue;
                }
                Double avgRSugar = (sum / userQuery.getQueryResults().size());
                sum = 0;

                for (WineSample nextSample : userQuery.getQueryResults()) {
                    double nextValue = nextSample.getChlorides();
                    sum += nextValue;
                }
                Double avgChlor = (sum / userQuery.getQueryResults().size());
                sum = 0;

                for (WineSample nextSample : userQuery.getQueryResults()) {
                    double nextValue = nextSample.getFreeSulfurDioxide();
                    sum += nextValue;
                }
                Double avgFSD = (sum / userQuery.getQueryResults().size());
                sum = 0;

                for (WineSample nextSample : userQuery.getQueryResults()) {
                    double nextValue = nextSample.getTotalSulfurDioxide();
                    sum += nextValue;
                }
                Double avgTSD = (sum / userQuery.getQueryResults().size());
                sum = 0;

                for (WineSample nextSample : userQuery.getQueryResults()) {
                    double nextValue = nextSample.getDensity();
                    sum += nextValue;
                }
                Double avgDens = (sum / userQuery.getQueryResults().size());
                sum = 0;

                for (WineSample nextSample : userQuery.getQueryResults()) {
                    double nextValue = nextSample.getpH();
                    sum += nextValue;
                }
                Double avgpH = (sum / userQuery.getQueryResults().size());
                sum = 0;

                for (WineSample nextSample : userQuery.getQueryResults()) {
                    double nextValue = nextSample.getSulphates();
                    sum += nextValue;
                }
                Double avgSulph = (sum / userQuery.getQueryResults().size());
                sum = 0;

                for (WineSample nextSample : userQuery.getQueryResults()) {
                    double nextValue = nextSample.getAlcohol();
                    sum += nextValue;
                }
                Double avgAlc = (sum / userQuery.getQueryResults().size());
                sum = 0;

                for (WineSample nextSample : userQuery.getQueryResults()) {
                    double nextValue = nextSample.getQuality();
                    sum += nextValue;
                }
                Double avgQual = (sum / userQuery.getQueryResults().size());

                //updating the statsTable with the calculated min, max and average attribute values
                sp.getStatsTable().setValueAt(minFAcid, 0, 1);
                sp.getStatsTable().setValueAt(maxFAcid, 0, 2);
                sp.getStatsTable().setValueAt(avgFAcid, 0, 3);
                sp.getStatsTable().setValueAt(minVAcid, 1, 1);
                sp.getStatsTable().setValueAt(maxVAcid, 1, 2);
                sp.getStatsTable().setValueAt(avgVAcid, 1, 3);
                sp.getStatsTable().setValueAt(minCAcid, 2, 1);
                sp.getStatsTable().setValueAt(maxCAcid, 2, 2);
                sp.getStatsTable().setValueAt(avgCAcid, 2, 3);
                sp.getStatsTable().setValueAt(minRSugar, 3, 1);
                sp.getStatsTable().setValueAt(maxRSugar, 3, 2);
                sp.getStatsTable().setValueAt(avgRSugar, 3, 3);
                sp.getStatsTable().setValueAt(minChlor, 4, 1);
                sp.getStatsTable().setValueAt(maxChlor, 4, 2);
                sp.getStatsTable().setValueAt(avgChlor, 4, 3);
                sp.getStatsTable().setValueAt(minFSD, 5, 1);
                sp.getStatsTable().setValueAt(maxFSD, 5, 2);
                sp.getStatsTable().setValueAt(avgFSD, 5, 3);
                sp.getStatsTable().setValueAt(minTSD, 6, 1);
                sp.getStatsTable().setValueAt(maxTSD, 6, 2);
                sp.getStatsTable().setValueAt(avgTSD, 6, 3);
                sp.getStatsTable().setValueAt(minDens, 7, 1);
                sp.getStatsTable().setValueAt(maxDens, 7, 2);
                sp.getStatsTable().setValueAt(avgDens, 7, 3);
                sp.getStatsTable().setValueAt(minpH, 8, 1);
                sp.getStatsTable().setValueAt(maxpH, 8, 2);
                sp.getStatsTable().setValueAt(avgpH, 8, 3);
                sp.getStatsTable().setValueAt(minSulph, 9, 1);
                sp.getStatsTable().setValueAt(maxSulph, 9, 2);
                sp.getStatsTable().setValueAt(avgSulph, 9, 3);
                sp.getStatsTable().setValueAt(minAlc, 10, 1);
                sp.getStatsTable().setValueAt(maxAlc, 10, 2);
                sp.getStatsTable().setValueAt(avgAlc, 10, 3);
                sp.getStatsTable().setValueAt(minQual, 11, 1);
                sp.getStatsTable().setValueAt(maxQual, 11, 2);
                sp.getStatsTable().setValueAt(avgQual, 11, 3);
                sp.getStatsTable().revalidate();
                sp.getStatsTable().repaint();
            }
        }
    }

    public static void main(String[] args) {
        PWB pwb = new PWB();
        Map<Integer, Collection<WineSample>> datasets = new HashMap<Integer, Collection<WineSample>>();
        Map<String, Method> keywords = new HashMap<String, Method>();

        try {
            pwb.readFiles("winequality-red.csv", "winequality-white.csv");

            //creating object representations for each of the WineSample accessor methods
            Class<?> cls = Class.forName("WineSample");
            Method getF_Acid = cls.getMethod("getFixedAcidity");
            Method getV_Acid = cls.getMethod("getVolatileAcidity");
            Method getC_Acid = cls.getMethod("getCitricAcid");
            Method getR_Sugar = cls.getMethod("getResidualSugar");
            Method getChlorid = cls.getMethod("getChlorides");
            Method getF_Sulf = cls.getMethod("getFreeSulfurDioxide");
            Method getT_Sulf = cls.getMethod("getTotalSulfurDioxide");
            Method getDens = cls.getMethod("getDensity");
            Method getPH = cls.getMethod("getpH");
            Method getSulph = cls.getMethod("getSulphates");
            Method getAlc = cls.getMethod("getAlcohol");
            Method getQual = cls.getMethod("getQuality");

            //populating the datasets HashMap with the WineSample collections and their
            //corresponding integer values
            datasets.put(0, pwb.getRedSamples());
            datasets.put(1, pwb.getWhiteSamples());
            datasets.put(2, pwb.getWineSamples());

            //populating the keywords HashMap with the query keywords from the assignment
            //specification and their corresponding Method objects
            keywords.put("f_acid", getF_Acid);
            keywords.put("v_acid", getV_Acid);
            keywords.put("c_acid", getC_Acid);
            keywords.put("r_sugar", getR_Sugar);
            keywords.put("chlorid", getChlorid);
            keywords.put("f_sulf", getF_Sulf);
            keywords.put("t_sulf", getT_Sulf);
            keywords.put("dens", getDens);
            keywords.put("pH", getPH);
            keywords.put("sulph", getSulph);
            keywords.put("alc", getAlc);
            keywords.put("qual", getQual);

            PWBrowserFrame browser = new PWBrowserFrame();
            browser.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            browser.setVisible(true);

            //so the Query and Condition objects created by the SubmitQueryListener can have their corresponding Map fields
            //set appropriately
            browser.setDatasets(datasets);
            browser.setKeywords(keywords);
        }
        catch (FileNotFoundException fnfe)  {
            System.out.println("One or more wine sample data input files do not exist");
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }
        catch (ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        }
        catch (NoSuchMethodException nsme) {
            nsme.printStackTrace();
        }
    }
}
public class NoWineTypeSelectionException extends Exception {
    public NoWineTypeSelectionException() {
    }

    public NoWineTypeSelectionException(String message) {
        super(message);
    }

    public NoWineTypeSelectionException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoWineTypeSelectionException(Throwable cause) {
        super(cause);
    }

    public NoWineTypeSelectionException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}

public class NoResultsFilterSelectionException extends Exception {
    public NoResultsFilterSelectionException() {
    }

    public NoResultsFilterSelectionException(String message) {
        super(message);
    }

    public NoResultsFilterSelectionException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoResultsFilterSelectionException(Throwable cause) {
        super(cause);
    }

    public NoResultsFilterSelectionException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}

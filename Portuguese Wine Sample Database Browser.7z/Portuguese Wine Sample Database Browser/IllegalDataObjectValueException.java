public class IllegalDataObjectValueException extends Exception {
	public IllegalDataObjectValueException() {
    }

    public IllegalDataObjectValueException(String message) {
        super(message);
    }

    public IllegalDataObjectValueException(Throwable cause) {
        super(cause);
    }

    public IllegalDataObjectValueException(String message, Throwable cause) {
        super(message, cause);
    }
}
import java.util.*;
import java.lang.reflect.*;

public class Condition {
	public static final int LESSER = 0;
	public static final int LESSER_EQUAL = 1;
	public static final int EQUAL = 2;
	public static final int NOT_EQUAL = 3;
	public static final int GREATER_EQUAL = 4;
	public static final int GREATER = 5;
	
	private String keyword;
	private int operator;
	private double value;
	//for mapping the query keywords to object representations of the relevant accessor methods
	private Map<String, Method> keywordMethods;
	
	public String getKeyword() {
		return keyword;
	}
	
	public int getOperator() {
		return operator;
	}
	
	public double getValue() {
		return value;
	}
	
	public Map<String, Method> getKeywordMethods() {
		return keywordMethods;
	}
	
	public void setKeyword(String s) {
		keyword = s;
	}
	
	public void setOperator(int i) {
		if (operator < 0 || operator > 5) {
			throw new IllegalArgumentException(
				"The operator value for a Condition must be between 0 and 5, inclusive.");
		}
		else {
			operator = i;
		}
	}
	
	public void setValue(double d) {
			value = d;
	}
	
	public void setKeywordMethods(Map<String, Method> m) {
		keywordMethods = m;
	}
	
	public <T extends Comparable> boolean isTrue(T dataObject) throws IllegalAccessException, 
	InvocationTargetException, IllegalDataObjectValueException, IllegalOperatorValueException {
		//looking up the relevant accessor method for the keyword in the HashMap
		//and invoking it on the data object using reflection
		Object returnObject = keywordMethods.get(keyword).invoke(dataObject);
		//avoiding class cast exceptions in case of non-numeric value
		//(e.g. from a non-instantiated data object resulting in null value)
		if (returnObject instanceof Number == false) {
			throw new IllegalDataObjectValueException();
		}
		//cast to Number instead of Double as a call to getQuality() will return an int
		Number dataObjectValue = (Number) returnObject;
		
		//comparing the data object's value with the condition's value according to the 
		//correct operator
		if (operator == Condition.LESSER) {
			if (dataObjectValue.doubleValue() < value) {
				return true;
			}
			else {
				return false;
			}
		}
		else if (operator == Condition.LESSER_EQUAL) {
			if (dataObjectValue.doubleValue() <= value) {
				return true;
			}
			else {
				return false;
			}
		}
		else if (operator == Condition.EQUAL) {
			if (dataObjectValue.doubleValue() == value) {
				return true;
			}
			else {
				return false;
			}
		}
		else if (operator == Condition.NOT_EQUAL) {
			if (dataObjectValue.doubleValue() != value) {
				return true;
			}
			else {
				return false;
			}
		}
		else if (operator == Condition.GREATER_EQUAL) {
			if (dataObjectValue.doubleValue() >= value) {
				return true;
			}
			else {
				return false;
			}
		}
		else if (operator == Condition.GREATER) {
			if (dataObjectValue.doubleValue() > value) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			//in case of a unitialised operator variable resulting in null value
			throw new IllegalOperatorValueException();
		}	
	}		
}
import java.util.*;

public class TotalSulfurDioxideComparator implements Comparator<WineSample> {
    public int compare(WineSample a, WineSample b) {
        return a.getTotalSulfurDioxide() < b.getTotalSulfurDioxide() ? -1 :
                a.getTotalSulfurDioxide() > b.getTotalSulfurDioxide() ? 1 : 0;
    }
}
import java.util.*;

public class DensityComparator implements Comparator<WineSample> {
    public int compare(WineSample a, WineSample b) {
        return a.getDensity() < b.getDensity() ? -1 :
                a.getDensity() > b.getDensity() ? 1 : 0;
    }
}
public class WineSample implements Comparable<WineSample> {
	public static final int RED = 0;
	public static final int WHITE = 1;
	
	private int sampleID;
	private int wineType;
	private double fixedAcidity;
	private double volatileAcidity;
	private double citricAcid;
	private double residualSugar;
	private double chlorides;
	private double freeSulfurDioxide;
	private double totalSulfurDioxide;
	private double density;
	private double pH;
	private double sulphates;
	private double alcohol;
	private int quality;
	
	public int getSampleID() {
		return sampleID;
	}
	
	public int getWineType() {
		return wineType;
	}
	
	public double getFixedAcidity() {
		return fixedAcidity;
	}
	
	public double getVolatileAcidity() {
		return volatileAcidity;
	}
	
	public double getCitricAcid() {
		return citricAcid;
	}
	
	public double getResidualSugar() {
		return residualSugar;
	}
	
	public double getChlorides() {
		return chlorides;
	}
	
	public double getFreeSulfurDioxide() {
		return freeSulfurDioxide;
	}
	
	public double getTotalSulfurDioxide() {
		return totalSulfurDioxide;
	}
	
	public double getDensity() {
		return density;
	}
	
	public double getpH() {
		return pH;
	}
	
	public double getSulphates() {
		return sulphates;
	}
	
	public double getAlcohol() {
		return alcohol;
	}
	
	public int getQuality() {
		return quality;
	}
	
	public void setSampleID(int i) {
		sampleID = i;
	}
	
	public void setWineType(int i) {
		wineType = i;
	}
	
	public void setFixedAcidity(double d) {
		fixedAcidity = d;
	}
	
	public void setVolatileAcidity(double d) {
		volatileAcidity = d;
	}
	
	public void setCitricAcid(double d) {
		citricAcid = d;
	}
	
	public void setResidualSugar(double d) {
		residualSugar = d;
	}
	
	public void setChlorides(double d) {
		chlorides = d;
	}
	
	public void setFreeSulfurDioxide(double d) {
		freeSulfurDioxide = d;
	}
	
	public void setTotalSulfurDioxide(double d) {
		totalSulfurDioxide = d;
	}
	
	public void setDensity(double d) {
		density = d;
	}
	
	public void setpH(double d) {
		pH = d;
	}
	
	public void setSulphates(double d) {
		sulphates = d;
	}
	
	public void setAlcohol(double d) {
		alcohol = d;
	}
	
	public void setQuality(int i) {
		quality = i;
	}
	
	//default means of sorting samples is by their IDs
	public int compareTo(WineSample sample) {
		return sampleID - sample.sampleID;
	}
	
	public String toString() {
		if (wineType == RED) {
			return "[" + sampleID + " RED, f_acid: " + fixedAcidity + ", v_acid: "
				+ volatileAcidity + ", c_acid: " + citricAcid + ", r_sugar: " +
				residualSugar + ", chlorid: " + chlorides + ", f_sulf: " + 
				freeSulfurDioxide + ", t_sulf: " + totalSulfurDioxide + ", dens: "
				+ density + ", pH: " + pH + ", sulph: " + sulphates + ", alc: "
				+ alcohol + ", qual: " + quality + "]";
		}
		else if (wineType == WHITE) {
			return "[" + sampleID + " WHITE, f_acid: " + fixedAcidity + ", v_acid: "
				+ volatileAcidity + ", c_acid: " + citricAcid + ", r_sugar: " +
				residualSugar + ", chlorid: " + chlorides + ", f_sulf: " + 
				freeSulfurDioxide + ", t_sulf: " + totalSulfurDioxide + ", dens: "
				+ density + ", pH: " + pH + ", sulph: " + sulphates + ", alc: "
				+ alcohol + ", qual: " + quality + "]";
		}
		else {
			return sampleID + " " + "WINE_TYPE UNSPECIFIED";
		}
	}
}
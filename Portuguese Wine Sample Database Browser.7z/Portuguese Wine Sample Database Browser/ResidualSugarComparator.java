import java.util.*;

public class ResidualSugarComparator implements Comparator<WineSample> {
    public int compare(WineSample a, WineSample b) {
        return a.getResidualSugar() < b.getResidualSugar() ? -1 :
                a.getResidualSugar() > b.getResidualSugar() ? 1 : 0;
    }
}
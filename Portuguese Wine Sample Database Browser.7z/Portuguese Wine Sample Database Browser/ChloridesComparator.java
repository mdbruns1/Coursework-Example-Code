import java.util.*;

public class ChloridesComparator implements Comparator<WineSample> {
    public int compare(WineSample a, WineSample b) {
        return a.getChlorides() < b.getChlorides() ? -1 :
                a.getChlorides() > b.getChlorides() ? 1 : 0;
    }
}
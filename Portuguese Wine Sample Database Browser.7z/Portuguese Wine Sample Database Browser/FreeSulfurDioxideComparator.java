import java.util.*;

public class FreeSulfurDioxideComparator implements Comparator<WineSample> {
    public int compare(WineSample a, WineSample b) {
        return a.getFreeSulfurDioxide() < b.getFreeSulfurDioxide() ? -1 :
                a.getFreeSulfurDioxide() > b.getFreeSulfurDioxide() ? 1 : 0;
    }
}
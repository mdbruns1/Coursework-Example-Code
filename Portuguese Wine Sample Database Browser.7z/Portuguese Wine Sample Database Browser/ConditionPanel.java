import javax.swing.*;

public class ConditionPanel extends JPanel {
    //components that need to be accessible to SubmitQueryListener are made instance variables
    private JComboBox<String> keywordOptions = new JComboBox<String>();
    private JComboBox<String> operatorOptions = new JComboBox<String>();
    private JTextField valueField = new JTextField(4);

    public ConditionPanel() {
        //users select from a scrollable list of appropriate keywords
        keywordOptions.addItem("");
        keywordOptions.addItem("f_acid");
        keywordOptions.addItem("v_acid");
        keywordOptions.addItem("c_acid");
        keywordOptions.addItem("r_sugar");
        keywordOptions.addItem("chlorid");
        keywordOptions.addItem("f_sulf");
        keywordOptions.addItem("t_sulf");
        keywordOptions.addItem("dens");
        keywordOptions.addItem("pH");
        keywordOptions.addItem("sulph");
        keywordOptions.addItem("alc");
        keywordOptions.addItem("qual");
        add(new JLabel("  Keyword:"));
        add(keywordOptions);

        //users select from a scrollable list of appropriate operator signs
        operatorOptions.addItem("");
        operatorOptions.addItem("<");
        operatorOptions.addItem("<=");
        operatorOptions.addItem("=");
        operatorOptions.addItem("!=");
        operatorOptions.addItem(">=");
        operatorOptions.addItem(">");
        add(new JLabel("  Operator:"));
        add(operatorOptions);

        //a blank text field stores user keyboard input
        add(new JLabel("  Value:"));
        add(valueField);

        setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Condition"));
    }

    public JComboBox<String> getKeywordOptions() {
        return keywordOptions;
    }

    public void setKeywordOptions(JComboBox<String> keywordOptions) {
        this.keywordOptions = keywordOptions;
    }

    public JComboBox<String> getOperatorOptions() {
        return operatorOptions;
    }

    public void setOperatorOptions(JComboBox<String> operatorOptions) {
        this.operatorOptions = operatorOptions;
    }

    public JTextField getValueField() {
        return valueField;
    }

    public void setValueField(JTextField valueField) {
        this.valueField = valueField;
    }
}

package crm.beans;

import java.util.List;
import java.util.ArrayList;

public class ReadingList {
    private int dbID;
    private String name;
    private List<CourseReading> readings = new ArrayList<CourseReading>();

    public ReadingList() {
    }

    public ReadingList(int dbID, String name) {
        this.dbID = dbID;
        this.name = name;
    }

    public int getDbID() {
        return dbID;
    }

    public void setDbID(int dbID) {
        this.dbID = dbID;
    }

    public ReadingList(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<CourseReading> getReadings() {
        return readings;
    }

    public void setReadings(List<CourseReading> readings) {
        this.readings = readings;
    }

    public void addReading(CourseReading cr) {
        readings.add(cr);
    }
}
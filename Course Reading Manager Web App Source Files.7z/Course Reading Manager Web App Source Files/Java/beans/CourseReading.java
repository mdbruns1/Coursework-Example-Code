package crm.beans;

public class CourseReading {
    private String author;
    private String pubYear;
    private String title;
    private String notes;
    private int dbID;

    public CourseReading() {
    }

    public CourseReading(String author, String pubYear, String title, String notes) {
        this.author = author;
        this.pubYear = pubYear;
        this.title = title;
        this.notes = notes;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPubYear() {
        return pubYear;
    }

    public void setPubYear(String pubYear) {
        this.pubYear = pubYear;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public int getDbID() {
        return dbID;
    }

    public void setDbID(int dbID) {
        this.dbID = dbID;
    }
}

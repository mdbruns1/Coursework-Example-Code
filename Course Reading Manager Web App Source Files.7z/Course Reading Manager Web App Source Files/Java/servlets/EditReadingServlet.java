package crm.servlets;

import crm.beans.CourseReading;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class EditReadingServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = (String) request.getParameter("username");
        int readingid = Integer.parseInt(request.getParameter("readingid"));
        String oldAuthor = request.getParameter("oldAuthor");
        String oldYear = request.getParameter("oldYear");
        String oldTitle = request.getParameter("oldTitle");
        String oldNotes = request.getParameter("oldNotes");
        CourseReading userReading = new CourseReading(oldAuthor, oldYear, oldTitle, oldNotes);
        userReading.setDbID(readingid);
        request.setAttribute("username", username);
        request.setAttribute("userReading", userReading);
        request.getRequestDispatcher("/WEB-INF/views/editreading.jsp").forward(request, response);
    }
}
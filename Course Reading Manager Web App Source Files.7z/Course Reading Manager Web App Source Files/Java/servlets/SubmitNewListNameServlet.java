package crm.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class SubmitNewListNameServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = (String) request.getParameter("username");
        String newListName = request.getParameter("newlistname");
        String formattedNewListName = "\'" + newListName + "\'";
        String listid = request.getParameter("listid");
        String updateListQuery = "UPDATE readinglists SET listname = " + formattedNewListName + " WHERE id " +
                "= " + listid;
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://143.167.9.232:3306/coursereadmandb",
                    "root", "team17");
            Statement st = con.createStatement();
            st.executeUpdate(updateListQuery);
        }
        catch (SQLException sqle) {
            sqle.printStackTrace();
        }
        catch (ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        }
        finally {
            try {
                if (con != null) {
                    con.close();
                }
            }
            catch (SQLException sqle) {
                sqle.printStackTrace();
            }
        }

        request.setAttribute("username", username);
        response.sendRedirect("/lists");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
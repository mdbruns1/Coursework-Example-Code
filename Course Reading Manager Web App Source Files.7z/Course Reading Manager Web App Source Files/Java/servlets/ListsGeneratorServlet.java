package crm.servlets;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import crm.beans.CourseReading;
import crm.beans.ReadingList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ListsGeneratorServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<ReadingList> userData = new ArrayList<ReadingList>();
        Connection con = null;
        String username = (String) request.getParameter("username");
        String formattedUsername = "\'" + username + "\'";
        String listQuery = "SELECT id, listname FROM readinglists WHERE username = " + formattedUsername;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://143.167.9.232:3306/coursereadmandb",
                "root", "team17");
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(listQuery);
            while (rs.next()) {
                int nextListID = rs.getInt("id");
                String nextListName = rs.getString("listname");
                ReadingList listResult = new ReadingList(nextListID, nextListName);
                userData.add(listResult);
            }
            for (ReadingList nextList : userData) {
                String dbIDAsString = String.valueOf(nextList.getDbID());
                String readingsQuery = "SELECT coursereadings.author, coursereadings.year, " +
                        "coursereadings.title, coursereadings.notes, coursereadings.readingid FROM coursereadings INNER JOIN " +
                        "readinglists ON coursereadings.listid = readinglists.id WHERE " +
                        "readinglists.id = " + dbIDAsString;
                Statement st2 = con.createStatement();
                ResultSet rs2 = st2.executeQuery(readingsQuery);
                while (rs2.next()) {
                    String nextReadingAuthor = rs2.getString("author");
                    String nextReadingPubYear = rs2.getString("year");
                    String nextReadingTitle = rs2.getString("title");
                    String nextReadingNotes = rs2.getString("notes");
                    int nextReadingDbID = rs2.getInt("readingid");
                    CourseReading readingResult = new CourseReading(
                            nextReadingAuthor, nextReadingPubYear, nextReadingTitle, nextReadingNotes);
                    readingResult.setDbID(nextReadingDbID);
                    nextList.addReading(readingResult);
                }
            }
        }
        catch (SQLException sqle) {
            sqle.printStackTrace();
        }
        catch (ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        }
        finally {
            try {
                if (con != null) {
                    con.close();
                }
            }
            catch (SQLException sqle) {
                sqle.printStackTrace();
            }
        }

        request.setAttribute("username", username);
        request.setAttribute("userData", userData);
        request.getRequestDispatcher("/views/lists.jsp").forward(request, response);
    }
}

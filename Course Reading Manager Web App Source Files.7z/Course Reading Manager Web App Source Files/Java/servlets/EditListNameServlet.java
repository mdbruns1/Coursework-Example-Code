package crm.servlets;

import crm.beans.ReadingList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class EditListNameServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = (String) request.getParameter("username");
        String oldListName = request.getParameter("oldlistname");
        int listid = Integer.parseInt(request.getParameter("listid"));
        ReadingList userList = new ReadingList(listid, oldListName);
        request.setAttribute("username", username);
        request.setAttribute("userList", userList);
        request.getRequestDispatcher("/WEB-INF/views/editlistname.jsp").forward(request, response);
    }
}

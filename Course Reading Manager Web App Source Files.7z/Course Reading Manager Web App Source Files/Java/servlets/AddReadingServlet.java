package crm.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class AddReadingServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = (String) request.getParameter("username");
        String author = request.getParameter("author");
        String pubYear = request.getParameter("year");
        String title = request.getParameter("title");
        String notes = request.getParameter("notes");
        String listid = request.getParameter("lists");
        String formattedAuthor = "(\'" + author + "\', ";
        String formattedPubYear = "\'" + pubYear + "\', ";
        String formattedTitle = "\'" + title + "\', ";
        String formattedNotes = "\'" + notes + "\', ";
        String formattedListID = "\'" + listid + "\')";
        String addReadingQuery = "INSERT INTO coursereadings (author, year, title, notes, listid) " +
                "VALUES " + formattedAuthor + formattedPubYear + formattedTitle + formattedNotes + formattedListID;
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://143.167.9.232:3306/coursereadmandb",
                    "root", "team17");
            Statement st = con.createStatement();
            st.executeUpdate(addReadingQuery);
        }
        catch (SQLException sqle) {
            sqle.printStackTrace();
        }
        catch (ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        }
        finally {
            try {
                if (con != null) {
                    con.close();
                }
            }
            catch (SQLException sqle) {
                sqle.printStackTrace();
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}